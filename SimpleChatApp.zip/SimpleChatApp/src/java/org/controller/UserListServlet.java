package org.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.constant.GlobalConstant;
import org.constant.UserListConstant;
import org.util.SessionUtil;

public class UserListServlet extends HttpServlet implements UserListConstant{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType(GlobalConstant.RESP_CONTENT_TYPE_JSON);
        JsonObject respJsonObject = new JsonObject();
        JsonArray usersJsonArray = new JsonArray();
        respJsonObject.add(JSON_NAME, usersJsonArray);
        SessionUtil sessionUtil = new SessionUtil();
        HttpSession curSession = req.getSession(false);
        if(null != GlobalConstant.HTTP_SESSION_LIST && null != curSession){
            for(HttpSession session : GlobalConstant.HTTP_SESSION_LIST){
                if(IS_LOG_ENABLED)LOGGER.info("session id: " + session.getId());
                if(session != curSession){
                    JsonObject object = new JsonObject();
                    object.addProperty(JSON_USER, sessionUtil.getUserName(session));
                    object.addProperty(JSON_SESSION_ID, session.getId());
                    usersJsonArray.add(object);
                }
            }
        }
        PrintWriter out = resp.getWriter();
        out.write(respJsonObject.toString());
        out.flush();
        out.close();
        out = null;
        respJsonObject = null;
        if(IS_LOG_ENABLED)LOGGER.info("user list send...");
    }
}
