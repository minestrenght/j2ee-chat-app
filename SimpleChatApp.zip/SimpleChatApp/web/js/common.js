(function(window, document){
    /* do nothing on window close */
    window.unload = function(){};
    
    /* force user to redirect on the latest page, avoiding back button */
    window.history.forward();
})(window, document);

/**
 * check whether debugging is enabled
 */
function isLogEnabled()   {return true;}

/**
 *  globally used for debugging
 */
function log_(toPrint){ 
    if(window.console && window.console.log && isLogEnabled()){
        window.console.log(arguments.callee.caller.name + " >>> ");
        window.console.log(toPrint);
    }
}