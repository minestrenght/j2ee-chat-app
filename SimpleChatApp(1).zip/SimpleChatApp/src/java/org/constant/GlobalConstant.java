package org.constant;

import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpSession;

public interface GlobalConstant {

    boolean             IS_LOG_ENABLED                  =  false;
    String              ATTR_SESSION_LIST               =  "attr.session.list";
    String              RESP_CONTENT_TYPE_JSON          =  "text/json";
    
    List<HttpSession>   HTTP_SESSION_LIST               =  new LinkedList<HttpSession>();
}
