package org.constant;

import java.util.logging.Logger;
import org.util.SessionUtil;

public interface SessionConstant {

    Logger      LOGGER                       =  Logger.getLogger(SessionUtil.class.getName());
    boolean     IS_LOG_ENABLED               =  GlobalConstant.IS_LOG_ENABLED && true;
    String      ATTR_USER_NAME               =  "attr.user.name";
    String      ATTR_ACTIVE_CHATS_MAP        =  "attr.active.chats.map";
    String      ATTR_ACTIVE_CHAT_MAP         =  "attr.active.chat.map";
    String      ATTR_CHAT_HISTORY            =  "attr.chat.history";
    String      ATTR_CUR_USER_NAME           =  "Me";
    String      ATTR_CHAT_TEXT               =  "attr.chat.text";
}
