package org.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.constant.LoginConstant;
import org.util.SessionUtil;

public class LoginServlet extends HttpServlet implements LoginConstant{
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(IS_LOG_ENABLED)LOGGER.info("doGet() starts...");
        String user = req.getParameter(PARAM_USER_NAME);
        String page = PAGE_ERROR;
        if(null != user && !user.isEmpty()){
            page = PAGE_SUCCESS;
            HttpSession httpSession = req.getSession();
            new SessionUtil().setUserDetails(user, httpSession);
        }
        if(IS_LOG_ENABLED)LOGGER.info("redirecting user to: " + page);
        if(IS_LOG_ENABLED)LOGGER.info("doGet() ends...");
        resp.sendRedirect(page);
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
