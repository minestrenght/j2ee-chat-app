package org.constant;

import java.util.logging.Logger;
import org.controller.ActiveChatListServlet;

public interface ActiveChatListConstant {

    Logger          LOGGER                  =   Logger.getLogger(ActiveChatListServlet.class.getName());
    boolean         IS_LOG_ENABLED          =   GlobalConstant.IS_LOG_ENABLED && true;
    String          JSON_NAME               =   "activeChatList";
    String          JSON_USER_NAME          =   "userName";
    String          JSON_SESSION_ID         =   "sessionId";
}
