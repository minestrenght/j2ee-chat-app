package org.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.constant.ActiveChatListConstant;
import org.constant.GlobalConstant;
import org.util.SessionUtil;

public class ActiveChatListServlet extends HttpServlet implements ActiveChatListConstant{
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession httpSession = req.getSession(false);
        resp.setContentType(GlobalConstant.RESP_CONTENT_TYPE_JSON);
        PrintWriter out = resp.getWriter();
        out.write (new SessionUtil().getActiveChatJsonObject(httpSession).toString());
        out.flush();
        out.close();
        out = null;
        if(IS_LOG_ENABLED)LOGGER.info("active chat list send...");
    }
}
