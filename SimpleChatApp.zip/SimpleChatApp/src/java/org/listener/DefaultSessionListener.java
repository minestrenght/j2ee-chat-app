package org.listener;

import java.util.logging.Logger;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import org.constant.SessionConstant;
import org.util.SessionUtil;

public class DefaultSessionListener implements SessionConstant, HttpSessionAttributeListener{
    
    private final static Logger LOGGER = Logger.getLogger(DefaultSessionListener.class.getName());
    
    /**
     * Adds session to the list only if any attribute is added to it
     * @param event 
     */
    public void attributeAdded(HttpSessionBindingEvent event) {
        final HttpSession session = event.getSession();
        new Thread(new Runnable() {
            public void run() {
                new SessionUtil().addSession(session);
            }
        }).start();
        if(IS_LOG_ENABLED)LOGGER.info("task assigned to add session ...");
    }

    public void attributeRemoved(HttpSessionBindingEvent event) {}

    public void attributeReplaced(HttpSessionBindingEvent event) {}
}
