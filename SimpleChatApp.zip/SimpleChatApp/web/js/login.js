/**
 * Performs basic validation for form submit
 */
(function(window, document){

    function getLoginForm()         {return $("#loginForm");}
    function getUserText()          {return $("#userNameText");}
    function getLoginErrorMsg()     {return "Please enter user name !!";}
    function URL()                  {return "login.do";}
    
    $(document).ready(function(){
        getLoginForm().submit(function(e){
            var canSubmit = false;
            log_("form submit event...");
            if ($.trim(getUserText().val()).length) {
                $(this).prop('action', URL());
                log_("redirecting to controller...");
                canSubmit = true;
            }
            else {
                log_("user details not filled...");
                alert(getLoginErrorMsg());
            }
            e.stopPropagation();
            return canSubmit;
        });
    });

})(window, document);
