package org.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpSession;
import org.constant.ActiveChatListConstant;
import org.constant.GetChatLogConstant;
import org.constant.GlobalConstant;
import org.constant.SessionConstant;

public class SessionUtil implements SessionConstant{
  
    /**
     * Add session to the list only if user attribute is added to it
     * @param httpSession 
     */
    public void addSession(HttpSession httpSession){
        if(!GlobalConstant.HTTP_SESSION_LIST.contains(httpSession) && null != httpSession.getAttribute(ATTR_USER_NAME)){
            GlobalConstant.HTTP_SESSION_LIST.add(httpSession);
            if(IS_LOG_ENABLED)LOGGER.info("session added...");
        }
    }
    
    /**
     * Removes given session from the application context list and destroys session
     * @param httpSession 
     */
    public void removeSession(HttpSession httpSession){
        if(GlobalConstant.HTTP_SESSION_LIST.remove(httpSession)){
            if(IS_LOG_ENABLED)LOGGER.info("session removed...");
        }
        if(null != httpSession){
            httpSession.invalidate();
        }
    }
        
    /**
     * Returns user name attribute from the given session
     * @param httpSession
     * @return 
     */
    public String getUserName(HttpSession httpSession){
        return null != httpSession ? (String)httpSession.getAttribute(ATTR_USER_NAME) : "";
    }
    
    /**
     * Sets required user details as attribute in the given session
     * @param user
     * @param session 
     */
    public void setUserDetails(String user, HttpSession session){
        session.setAttribute(ATTR_USER_NAME, user);
        session.setAttribute(ATTR_ACTIVE_CHATS_MAP, new HashMap<String, List>());
    }
    
    /**
     * Returns the chat history for the given session.
     * @param httpSession
     * @return 
     */
    private Map<String, List> getActiveChatMap(HttpSession httpSession){
        return null != httpSession ? (Map<String, List>)httpSession.getAttribute(ATTR_ACTIVE_CHATS_MAP) : null;
    }
    
    /**
     * Adds the given text in the http session attribute for both the users
     * @param otherSessionId
     * @param httpSession
     * @param text
     * @return 
     */
    public boolean addText(String otherSessionId, HttpSession httpSession, String text){
        // for end user
        HttpSession session = getHttpSession(otherSessionId);
        String userName = getUserName(httpSession);
        String id = httpSession.getId();
        boolean b1 = addChatText(id, session, text, userName);
        if(IS_LOG_ENABLED)LOGGER.info("b1 = " + b1);

        // for current user
        id = otherSessionId;
        session = httpSession;
        userName = ATTR_CUR_USER_NAME;
        boolean b2 = addChatText(id, session, text, userName);
        if(IS_LOG_ENABLED)LOGGER.info("b2 = " + b2);
        return b1 && b2;
    }
    
    /**
     * Adds chat text in chat history for given user's session
     * @param sessionId
     * @param httpSession
     * @param text
     * @param userName
     * @return 
     */
    private boolean addChatText(String sessionId, HttpSession httpSession, String text, String userName){
        boolean toReturn = false;
        Map<String, List> chatsMap = getActiveChatMap(httpSession);
        if(null != chatsMap){
            List<Map> chatHistory = chatsMap.get(sessionId);
            if(null == chatHistory){
                chatHistory = new LinkedList<Map>();
                chatsMap.put(sessionId, chatHistory);
            }
            Map<String, String> chatMap = new HashMap<String, String>();
            chatMap.put(ATTR_USER_NAME, userName);
            chatMap.put(ATTR_CHAT_TEXT, text);
            if(IS_LOG_ENABLED){
                LOGGER.info(chatHistory.toString());
            }
            chatHistory.add(chatMap);
            toReturn = true;
        }
        else {
            if(IS_LOG_ENABLED)LOGGER.info("chat map is null !!" + httpSession);
        }
        return toReturn;
    }
    
    /**
     * Returns HttpSession for given sessionId
     * @param sessionId
     * @param httpSession
     * @return 
     */
    private HttpSession getHttpSession(String sessionId){
        HttpSession toReturn = null;
        List<HttpSession> httpSessions = GlobalConstant.HTTP_SESSION_LIST;
        if(null != httpSessions && !httpSessions.isEmpty()){
            boolean match;
            for(HttpSession session : httpSessions){
                match = sessionId.equals(session.getId());
                if(IS_LOG_ENABLED)LOGGER.info(String.format("%s == %s : %b", sessionId, session.getId(), match));
                if(match){
                    toReturn = session;
                    break;
                }
            }
        }else{
            if(IS_LOG_ENABLED)LOGGER.info("http session list is null or empty !!");
        }
        return toReturn;
    }
    
    /**
     * Returns the chat history for the given user's session id
     * @param sessionId
     * @param httpSession
     * @return 
     */
    public JsonArray getChatLog(String sessionId, HttpSession httpSession){
        JsonArray toReturnJsonArray = new JsonArray();
        Map<String, List> chatsMap = getActiveChatMap(httpSession);
        if(IS_LOG_ENABLED){
            LOGGER.info(chatsMap.toString());
        }
        if(null != chatsMap){
            if(IS_LOG_ENABLED)LOGGER.info(chatsMap.keySet().toString());
            List<Map> chatList = chatsMap.get(sessionId);
            if(null != chatList){
                JsonObject jsonObject;
                for(Map<String, String> chat: chatList){
                    jsonObject = new JsonObject();
                    jsonObject.addProperty(GetChatLogConstant.JSON_LOG_NAME, chat.get(ATTR_USER_NAME));
                    jsonObject.addProperty(GetChatLogConstant.JSON_LOG_TEXT, chat.get(ATTR_CHAT_TEXT));
                    toReturnJsonArray.add(jsonObject);
                }
            }
            else{
                if(IS_LOG_ENABLED){
                    LOGGER.info("chat list is null !!");
                }
            }
        }else{
            if(IS_LOG_ENABLED){
                LOGGER.info("chat map is null !!");
            }
        }
        if(IS_LOG_ENABLED)LOGGER.info("chat log size is: " + toReturnJsonArray.size());
        return toReturnJsonArray;
    }
    
    /**
     * Returns the json object for the active chat list, containing the list of<br>
     * users who are chatting with the user or vice-versa
     * @param httpSession
     * @return 
     */
    public JsonObject getActiveChatJsonObject (HttpSession httpSession){
        JsonObject toReturnJsonObject = new JsonObject();
        JsonArray activeChatList = new JsonArray();
        if(null != httpSession){
            toReturnJsonObject.add(ActiveChatListConstant.JSON_NAME, activeChatList);
            Map<String, List> chatsMap = getActiveChatMap(httpSession);
            if(null != chatsMap){
                Set<String> ids = chatsMap.keySet();
                if(null != ids){
                    String user;
                    HttpSession hs;
                    JsonObject jo;
                    for(String id : ids){
                        hs = getHttpSession(id);
                        if(null != hs){
                            jo = new JsonObject();
                            user = getUserName(hs);
                            jo.addProperty(ActiveChatListConstant.JSON_USER_NAME, user);
                            jo.addProperty(ActiveChatListConstant.JSON_SESSION_ID, id);
                            activeChatList.add(jo);
                        }
                    }
                }
            }
        }
        return toReturnJsonObject;
    }
}
