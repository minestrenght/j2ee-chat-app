package org.controller;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.constant.GetChatLogConstant;
import org.constant.GlobalConstant;
import org.util.SessionUtil;

public class GetChatLogServlet extends HttpServlet implements GetChatLogConstant {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if(IS_LOG_ENABLED)LOGGER.info("populating chat log...");
        String id = req.getParameter(PARAM_SESSION_ID);
        if(IS_LOG_ENABLED)LOGGER.info("chat id: " + id);
        JsonObject jsonObject = new JsonObject();
        jsonObject.add(JSON_NAME, new SessionUtil().getChatLog(id, req.getSession(false)));
        resp.setContentType(GlobalConstant.RESP_CONTENT_TYPE_JSON);
        PrintWriter out = resp.getWriter();
        out.write(jsonObject.toString());
        out.flush();
        out.close();
        if(IS_LOG_ENABLED)LOGGER.info("chat log send...");
    }

}
