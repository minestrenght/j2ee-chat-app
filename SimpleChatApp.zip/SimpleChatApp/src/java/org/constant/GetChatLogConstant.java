package org.constant;

import java.util.logging.Logger;
import org.controller.GetChatLogServlet;

public interface GetChatLogConstant {
    
    boolean    IS_LOG_ENABLED      =  GlobalConstant.IS_LOG_ENABLED && true;
    Logger     LOGGER              =  Logger.getLogger(GetChatLogServlet.class.getName());
    String     JSON_NAME           =  "chatLogs";
    String     JSON_LOG_NAME       =  "name";
    String     JSON_LOG_TEXT       =  "text";
    String     PARAM_SESSION_ID    =  "id";
}
