/**
 * This js will populate the list of all logged - in users except for the current user
 */
(function(window, document){
    function getOnlineUserDiv()         {return $("#onlineUsersDiv");}
    function getDelay()                 {return 5 * 1000;}
    function getListName()              {return "onlineUsersList";}
    function getUserName()              {return "userName";}
    function getSessionName()           {return "sessionId";}    
    function getServerErrorMsg()        {return "Server encountered problem...";}
    function getListUrl()               {return "userList.do";}
    function getLoadingMsg()            {return "Loading users list...";}
    function getNoUserMsg()             {return "None of the users are online !";}
    function getNoJsonErrorMsg()        {return "Json is required !!";}
    function getChatUrl()               {return "chat-room.html?id=";}
    
    $(document).ready(function(){
        setInterval(function(){
            log_("sending request...");
            $.ajax({
                url: getListUrl(),
                success: function(json){
                    getOnlineUserDiv().html(getLoadingMsg());
                    populateOnlineDiv(json);
                },
                error: function(){
                    getOnlineUserDiv().html(getServerErrorMsg());
                }
            });
        }, getDelay());
    });
      
    function populateOnlineDiv(json){
        if(!json) throw getNoJsonErrorMsg();
        var list = json[getListName()];
        var len = list.length;
        if(!len){
            getOnlineUserDiv().html(getNoUserMsg());
        }else{
            getOnlineUserDiv().html('');
            while(len --){
                var div = $("<div class='row'>");
                getOnlineUserDiv().append(div);
                var a = $("<a href='javascript:void(0);' onclick='window.open(\""+getChatUrl()+list[len][getSessionName()]+"\")'>");
                a.html(list[len][getUserName()]);
                div.append(a);
            }
        }
    }
})(window, document);