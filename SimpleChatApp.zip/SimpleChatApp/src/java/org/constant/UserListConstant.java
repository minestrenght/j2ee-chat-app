package org.constant;

import java.util.logging.Logger;
import org.controller.UserListServlet;

public interface UserListConstant {

    Logger      LOGGER                  =  Logger.getLogger(UserListServlet.class.getName());
    boolean     IS_LOG_ENABLED          =  GlobalConstant.IS_LOG_ENABLED && true;
    String      JSON_NAME               =  "onlineUsersList";
    String      JSON_USER               =  "userName";
    String      JSON_SESSION_ID         =  "sessionId";
}
