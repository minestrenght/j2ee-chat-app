package org.controller;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.constant.GlobalConstant;
import org.constant.VerifyLoginConstant;
import org.util.SessionUtil;

public class VerifyLoginServlet extends HttpServlet implements VerifyLoginConstant{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession httpSession = req.getSession(false);
        JsonObject jsonObject = new JsonObject();
        SessionUtil sessionUtil = new SessionUtil();
        boolean flag = sessionUtil.getUserName(httpSession).isEmpty();
        flag = !flag;
        JsonObject jo = new JsonObject();
        jsonObject.add(JSON_NAME, jo);
        jo.addProperty(JSON_STATUS, flag);
        resp.setContentType(GlobalConstant.RESP_CONTENT_TYPE_JSON);
        PrintWriter out = resp.getWriter();
        out.write(jsonObject.toString());
        out.flush();
        out.close();
        out = null;
        if(IS_LOG_ENABLED)logger.info(String.format("user logged in status: %s", flag));
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
