/**
 * This js is for verifying whether the user viewing the current page is logged in or not.
 * If user is not logged-in, a alert will be show to login, after that user will be redirected to login page.
 */
(function(window, document){

    function getVerificationUrl()       {return "isLoggedIn.do";}
    function getJsonName()              {return "userLoginStatus";}
    function getJsonStatus()            {return "isLoggedIn";}
    function getLoginUrl()              {return "login.html";}
    function getDelay()                 {return 4.5 * 1000;}
    function getLoginReqMsg()           {return "Your session has expired,\nyou must login first...";}
    
    $(document).ready(function(){
        setInterval(function (){
            $.ajax({
                url: getVerificationUrl(),
                success:verifyUserStatus,
                error:showError
            });
        }, getDelay());
    });
    
    function verifyUserStatus(json){
        if(json){
            var obj = json[getJsonName()];
            if(obj){
                var isLoggedIn = obj[getJsonStatus()];
                if(!isLoggedIn && undefined != isLoggedIn){
                    alert(getLoginReqMsg());
                    window.location = getLoginUrl();
                }
            }
        }
    }
    
    function showError(){
        log_("Problem verifying user status !!");
    }
})(window, document);