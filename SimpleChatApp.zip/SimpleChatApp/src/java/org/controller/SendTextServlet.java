package org.controller;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.constant.GlobalConstant;
import org.constant.SendTextConstant;
import static org.constant.SendTextConstant.IS_LOG_ENABLED;
import static org.constant.SendTextConstant.LOGGER;
import org.util.SessionUtil;

public class SendTextServlet extends HttpServlet implements SendTextConstant{

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter(PARAM_SESSION_ID);
        if(IS_LOG_ENABLED)LOGGER.info("user session id: " + id);
        String text = req.getParameter(PARAM_TEXT);
        if(IS_LOG_ENABLED)LOGGER.info("user text: " + text);
        boolean status = JSON_STATUS_FAILURE;
        SessionUtil sessionUtil = new SessionUtil();
        try{
            status = sessionUtil.addText(id, req.getSession(false), text);
        }
        catch(Exception exception){
            if(IS_LOG_ENABLED)LOGGER.info(exception.toString());
            exception.printStackTrace();
        }
        resp.setContentType(GlobalConstant.RESP_CONTENT_TYPE_JSON);
        JsonObject respJsonObject = new JsonObject();
        JsonObject jo = new JsonObject();
        jo.addProperty(JSON_STATUS,status);
        respJsonObject.add(JSON_NAME, jo);
        PrintWriter out = resp.getWriter();
        out.write(respJsonObject.toString());
        out.flush();
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
