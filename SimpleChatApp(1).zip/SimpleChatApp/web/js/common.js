(function(window, document, undefined){
    
    window.unload = function(){};
    
    window.history.forward();
    
})(window, document);

function log_(toPrint){
    if(window.console && window.console.log && true){
        window.console.log(toPrint);
    }
}