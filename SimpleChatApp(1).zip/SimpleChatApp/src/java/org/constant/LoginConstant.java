package org.constant;

import java.util.logging.Logger;
import org.controller.LoginServlet;

public interface LoginConstant {

    String      PARAM_USER_NAME               =  "user";
    String      PAGE_ERROR                    =  "login.html";
    String      PAGE_SUCCESS                  =  "user-list.html";
    Logger      LOGGER                        =  Logger.getLogger(LoginServlet.class.getName());
    boolean     IS_LOG_ENABLED                =  GlobalConstant.IS_LOG_ENABLED && true;
}
