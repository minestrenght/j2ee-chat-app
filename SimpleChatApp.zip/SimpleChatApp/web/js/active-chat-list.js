/**
 * This js will generate the list of active chats only
 *
 */
(function(window, document){


    function getActiveChatDiv()         {return $("#activeChatDiv");}
    function ACTIVE_URL()               {return "activeChatList.do";}
    function JSON_NAME()                {return "activeChatList";}
    function JSON_USER_NAME()           {return "userName";}
    function JSON_SESSION_ID()          {return "sessionId";}
    function DELAY()                    {return 4.5 * 1000;}
    function getServerErrorMsg()        {return "Server encountered problem !!";}
    function AJAX_METHOD_TYPE()         {return "post";}
    function getLoginReqdMsg()          {return "You must login to chat !!";}
    function getNoActiveChatMsg()       {return "You have no active chats !!";}
    function CHAT_URL()                 {return "chat-room.html?id=";}

    $(document).ready(function(){
        setInterval(function(){
            $.ajax({
                url: ACTIVE_URL(),
                type: AJAX_METHOD_TYPE(),
                success: populateActiveChat,
                error: showError
            });
        }, DELAY());
    });

    function populateActiveChat(json){
        var htm = "";
        if(json && json[JSON_NAME()]){
            var list = json[JSON_NAME()];
            if(list){
                var len = list.length;
                if(len){
                    while(len --){
                        var rec = list[len];
                        var user = rec[JSON_USER_NAME()];
                        var id = rec[JSON_SESSION_ID()];
                        htm += "<div class='row'>";
                        htm += "<a href='javascript:void(0);' onclick='window.open(\"";
                        htm += CHAT_URL() + id;
                        htm += "\");'>" + user + "</a>";
                        htm += "</div>";
                    }
                }else{
                    htm = getNoActiveChatMsg();
                }
            }else{
                log_("chat list is not available!!");
            }
        }else{
            htm = getLoginReqdMsg();
        }
        getActiveChatDiv().html(htm);
    }
    
    function showError(){
        getActiveChatDiv().html(getServerErrorMsg());
    }
})(window, document);