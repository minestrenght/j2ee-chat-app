package org.constant;

import java.util.logging.Logger;
import org.controller.SendTextServlet;

public interface SendTextConstant {

    boolean     IS_LOG_ENABLED          =  GlobalConstant.IS_LOG_ENABLED && true;
    Logger      LOGGER                  =  Logger.getLogger(SendTextServlet.class.getName());
    String      PARAM_SESSION_ID        =  "id";
    String      PARAM_TEXT              =  "text";
    String      JSON_NAME               =  "message";
    String      JSON_STATUS             =  "status";
    boolean     JSON_STATUS_SUCCESS     =  true;
    boolean     JSON_STATUS_FAILURE     =  false;
}
