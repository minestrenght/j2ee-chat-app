package org.constant;

import java.util.logging.Logger;
import org.controller.VerifyLoginServlet;

public interface VerifyLoginConstant {
    
    Logger      logger              =   Logger.getLogger(VerifyLoginServlet.class.getName());
    String      JSON_NAME           =   "userLoginStatus";
    String      JSON_STATUS         =   "isLoggedIn";
    boolean     IS_LOG_ENABLED      =   GlobalConstant.IS_LOG_ENABLED && true;
}
