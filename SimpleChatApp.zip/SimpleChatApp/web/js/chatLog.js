/**
 * This js will get the chat history from the session list
 */
(function(window, document){

    function JSON_NAME()        {return "chatLogs";}
    function JSON_LOG_NAME()    {return "name";}
    function JSON_LOG_TEXT()    {return "text";}
    function JSON_LOG_SELF()    {return "Me";}
    
    function DELAY()            {return 2.5 * 1000;}
    
    function URL()              {return "getChatLog.do";}
    function DATA()             {return "id=";}

    function getChatDiv()       {return $("#chatDiv");}
    
    $(document).ready(function(){
        id = window.location.search.substring(1);
        id = id.substring(id.indexOf("="));
        DATA = function() {return "id" + id};
    });
    
    /* fetch chat log */
    $(document).ready(function(){
        setInterval(function(){
            $.ajax({
                url: URL(),
                data: DATA(),
                success: function(json){
                    populateChatHistory(json);
                },
                error: function(){
                    //
                }
            });
        }, DELAY());
    });
    
    function populateChatHistory(json){
        var logs = json[JSON_NAME()];
        var title = "Chat with...";
        var name = ""
        if(logs){
            var len = logs.length;
            var i = 0;
            var chat = "";
            while(i < len){
                var log = logs[i];
                chat += "<div class='";
                if(JSON_LOG_SELF() == log[JSON_LOG_NAME()]){
                    chat += "right-row";
                }else{
                    chat += "left-row";
                    name = log[JSON_LOG_NAME()];
                }
                chat += "'>" + log[JSON_LOG_NAME()] + ": " + log[JSON_LOG_TEXT()] + "</div>";
                i ++;
            }
            document.title = title + name;
            getChatDiv().html(chat);
        }
    }
})(window, document);