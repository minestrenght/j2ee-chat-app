(function(window, document){

    function getLoginForm()         {return $("#loginForm");}
    function getUserText()          {return $("#userNameText");}
    function getLoginErrorMsg()     {return "Please enter user name !!";}
    function URL()                  {return "login.do";}
    
    $(document).ready(function(){
        getLoginForm().submit(function(e){
            log_("form submit event...");
            if ($.trim(getUserText().val()).length) {
                $(this).prop('action', URL());
                log_("redirecting to controller...");
            }
            else {
                log_("user details not filled...");
                alert(getLoginErrorMsg());
            }
            e.stopPropagation();
            return true;
        });
    });

})(window, document);
