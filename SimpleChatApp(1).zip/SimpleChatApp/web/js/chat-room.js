(function(window, document){

    var getSendTextUrl = function(){return "#";};

    function getDelay()         {return 4.5 * 1000;}
    function getChatText()      {return $("#chatText");}
    function getChatBtn()       {return $("#chatBtn");}
    function getChatDiv()       {return $("#chatDiv");}
    function getEnterKey()      {return 13;}
    
    function JSON_NAME()        {return "message";}
    function JSON_STATUS()      {return "status";}
    function CUR_USER_NAME()    {return "Me";}
    
    $(document).ready(function(){
        id = window.location.search.substring(1);
        id = id.substring(id.indexOf("="));
        getSendTextUrl = function(){ return "sendText.do?id" + id;};
    });
    
    $(document).ready(function(){
        getChatBtn().click(function(e){
            sendChatText();
        });
    });
    
    $(document).ready(function(){
        getChatText().keyup(function(e){
            if(getEnterKey() == e.which){
                sendChatText();
            }
        });
    });

    function sendChatText(){
        var txt = getChatText().val();
        if($.trim(txt).length){
            var div = $("<div class='right-row'>" + CUR_USER_NAME() + ": "+txt+"</div>");
            getChatDiv().append(div);
            
            $.ajax({
                url:getSendTextUrl(),
                data: "text=" + txt,
                type: "post",
                success:function(json){
                    log_(json);
                },
                error:function(){
                    log_("Server encountered problem...");
                }
            });
        }
        getChatText().val('');
    }
})(window, document);